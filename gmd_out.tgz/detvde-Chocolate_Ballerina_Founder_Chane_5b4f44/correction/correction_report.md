# Correction report: detvde-Chocolate_Ballerina_Founder_Chane_5b4f44

- 30 candidate intervals: {'ambiguous': 14, 'moment': 16}
- 'moment' durations (s): min 4, median 12, mean 34.7, max 224
- pooled candidate changes: 107 (29 accepted, 78 rejected); human decisions: 0
- accepted by evidence: {'activity': 9, 'activity+visual_transition': 5, 'activity+environment+visual_transition': 4, 'environment+visual_transition': 4, 'activity+people': 2, 'activity+people+visual_transition': 2, 'audio+environment+people+visual_transition': 1, 'activity+environment+people+visual_transition': 1, 'environment+people+visual_transition': 1}
- rejected by evidence: {'people+visual_transition': 31, 'visual_transition': 17, 'activity': 11, 'audio': 7, 'people': 6, 'audio+people': 3, 'audio+visual_transition': 2, 'environment': 1}
- noise-floor corrections: 98; human activity overrides: 0
- parameters: persist alone 6.0 s, supported 4.0 s, threshold 1.0, weights {'activity': 1.0, 'activity_short': 0.6, 'activity_family': 0.5, 'environment': 0.6, 'visual_transition': 0.4, 'people': 0.4, 'people_at_cut': 0.2, 'audio': 0.3, 'observability': 1.0}

| id | span (s) | dur | status | activities (share of 2 s steps) | sub-events | environment | start | end |
|---|---|---:|---|---|---|---|---|---|
| c000 | 0-6 | 6 | ambiguous | uncertain 0.667, talking to the camera 0.333 |  | a stage or auditorium | start | audio+environment+people+visual_transition |
| c001 | 6-18 | 12 | moment | talking to the camera 0.5, uncertain 0.333, eating or drinking 0.167 | talking to the camera 6-10 | a television studio | audio+environment+people+visual_transition | activity |
| c002 | 18-24 | 6 | moment | eating or drinking 1.0 | eating or drinking 18-24 | a television studio | activity | activity |
| c003 | 24-66 | 42 | ambiguous | uncertain 0.667, talking to the camera 0.143, applauding 0.095 | talking to the camera 24-30; applauding 36-40; talking while seated 54-58 | a television studio | activity | activity+environment+visual_transition |
| c004 | 66-74 | 8 | ambiguous | applauding 0.5, uncertain 0.5 | applauding 66-70 | a television studio | activity+environment+visual_transition | activity+people |
| c005 | 74-186 | 112 | moment | talking to the camera 0.679, uncertain 0.321 | talking to the camera 74-84; talking to the camera 86-92; talking to the camera 94-98; talking to the camera 100-104 | a television studio | activity+people | environment+visual_transition |
| c006 | 186-198 | 12 | ambiguous | uncertain 1.0 |  | a stage or auditorium | environment+visual_transition | activity+visual_transition |
| c007 | 198-206 | 8 | moment | dancing 0.75, uncertain 0.25 | dancing 198-204 | a stage or auditorium | activity+visual_transition | activity+environment+people+visual_transition |
| c008 | 206-430 | 224 | moment | talking to the camera 0.821, uncertain 0.179 | talking to the camera 206-220; talking to the camera 222-226; talking to the camera 228-240; talking to the camera 242-276 | a television studio | activity+environment+people+visual_transition | environment+visual_transition |
| c009 | 430-454 | 24 | ambiguous | uncertain 0.667, talking to the camera 0.333 | talking to the camera 436-444 | a television studio | environment+visual_transition | activity+environment+visual_transition |
| c010 | 454-476 | 22 | moment | dancing 0.909, uncertain 0.091 | dancing 454-474 | a stage or auditorium | activity+environment+visual_transition | activity |
| c011 | 476-482 | 6 | moment | playing a musical instrument 1.0 | playing a musical instrument 476-482 | a stage or auditorium | activity | activity+people |
| c012 | 482-486 | 4 | moment | dancing 1.0 | dancing 482-486 | a stage or auditorium | activity+people | environment+visual_transition |
| c013 | 486-488 | 2 | ambiguous | uncertain 1.0 |  | a television studio | environment+visual_transition | activity+visual_transition |
| c014 | 488-516 | 28 | moment | talking to the camera 0.929, uncertain 0.071 | talking to the camera 488-514 | a television studio | activity+visual_transition | activity+visual_transition |
| c015 | 516-596 | 80 | ambiguous | uncertain 0.5, talking while seated 0.3, talking to the camera 0.15 | demonstrating or presenting an object 516-520; talking while seated 530-534; talking to the camera 534-540; talking to the camera 542-548 | a television studio | activity+visual_transition | activity+environment+visual_transition |
| c016 | 596-606 | 10 | moment | working with tools 0.8, uncertain 0.2 | working with tools 596-604 | a stage or auditorium | activity+environment+visual_transition | activity+people+visual_transition |
| c017 | 606-626 | 20 | moment | demonstrating or presenting an object 0.9, uncertain 0.1 | demonstrating or presenting an object 606-624 | a television studio | activity+people+visual_transition | activity+visual_transition |
| c018 | 626-660 | 34 | ambiguous | uncertain 0.765, playing a musical instrument 0.235 | playing a musical instrument 626-630; playing a musical instrument 634-638 | a television studio | activity+visual_transition | environment+people+visual_transition |
| c019 | 660-682 | 22 | ambiguous | uncertain 0.818, talking to the camera 0.182 | talking to the camera 676-680 | a television studio | environment+people+visual_transition | activity+people+visual_transition |
| c020 | 682-722 | 40 | ambiguous | uncertain 0.6, demonstrating or presenting an object 0.4 | demonstrating or presenting an object 682-698 | a television studio | activity+people+visual_transition | activity+visual_transition |
| c021 | 722-802 | 80 | ambiguous | uncertain 0.7, singing 0.1, dancing 0.1 | talking while standing 722-726; singing 748-752; dancing 754-758; singing 758-762 | a television studio | activity+visual_transition | activity |
| c022 | 802-838 | 36 | moment | singing 0.556, uncertain 0.444 | singing 802-806; singing 808-816; singing 830-838 | a television studio | activity | activity |
| c023 | 838-852 | 14 | ambiguous | uncertain 0.571, applauding 0.429 | applauding 838-844 | a television studio | activity | activity |
| c024 | 852-878 | 26 | ambiguous | uncertain 0.462, dancing 0.385, singing 0.154 | dancing 852-856; dancing 862-868; singing 872-876 | a television studio | activity | activity |
| c025 | 878-880 | 2 | ambiguous | applauding 1.0 |  | a television studio | activity | environment+visual_transition |
| c026 | 880-884 | 4 | moment | applauding 1.0 | applauding 880-884 | a stage or auditorium | environment+visual_transition | activity |
| c027 | 884-896 | 12 | moment | dancing 1.0 | dancing 884-896 | a stage or auditorium | activity | activity |
| c028 | 896-906 | 10 | moment | applauding 0.8, uncertain 0.2 | applauding 896-904 | a stage or auditorium | activity | activity+environment+visual_transition |
| c029 | 906-946.492 | 40.492 | moment | demonstrating or presenting an object 0.75, uncertain 0.25 | demonstrating or presenting an object 906-914; demonstrating or presenting an object 916-938 | a television studio | activity+environment+visual_transition | end |